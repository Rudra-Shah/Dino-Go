let d = 40;
let col = 0;
let times = [];
let now;
let txt = "Hello there. Click the Red button when it turns Yellow. You will have 5 attempts.";
let song;
let bg;

function setup() {
  createCanvas(600, 600);
       var drawbutton = createButton('Home Screen');
 drawbutton.position(0, 580);
  drawbutton.mousePressed(gotolink_act1);
    song = loadSound('bellwav-14687.mp3');
    bg = loadImage('F1 Background.jpg');
}

function timeoutChange(changeSize) {
  const time = random(1500, 4000);
  setTimeout(() => {
    col = 255;
    now = millis();
    if (changeSize) {
      d = width;
    }
  }, time);
}

function mousePressed() {
  if (txt != "") {
    d = 40;
    txt = "";
    times.splice(0, 5);
    timeoutChange();
  } else {
    col = 0;
    const reactionTime = (millis() - now) / 1000;
    times.push(reactionTime);
    if (times.length < 5) {
      timeoutChange(times.length == 4);
    } else {
      let avg = 0;
      let description = "";
      for (let i of times) {
        avg += i;
      }
      avg /= times.length;
      if (avg < 0.22) {
        description = "That was super fast!";
        song.play();
      } else if (avg < 0.26) {
        description = "That was very fast!";
        song.play();
      } else if (avg < 0.30) {
        description = "That was fast.";
        song.play();
      } else if (avg < 0.34) {
        description = "Well done.";
        song.play();
      }
     txt = `ex${avg.toFixed(3)}
${description}
Click to play again.`;
    }
  }
}

function draw() {
  background(bg);
  
  noStroke();
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(16);
  text(txt, width/2, height/2);
  
  if (txt != "Click now to play.") {
    stroke(255);
    line(50, 20, width-50, 20);
    for (let i of times) {
      noStroke();
      fill(255, 255, 0, 230);
      circle(50 + i*400, 20, 10);
    }
  }
  
  if (txt == "") {
    noStroke();
    fill(255, col, 0);
    circle(width/2, height/2, d);
  }

}
function gotolink_act1() {
	window.open('https://editor.p5js.org/Rudra_shah/full/Vf9NJ0gTM');
}