let x, y;
let x1, y1;
let score = 0;
let radius ;
let counter=0
let r, g, b;
let screen = 0;
let timer = 0;
let winSound;

function setup() {
  createCanvas(600, 600);
  newCircle();
  var drawbutton = createButton('Home Screen');
 drawbutton.position(0, 0);
  drawbutton.mousePressed(gotolink_act1);
  winSound = loadSound('correct-2-46134.mp3');
}
function draw() {
	if(screen == 0){
    startScreen()
  }else if(screen == 1){
  	gameOn()
  }else if(screen==2){
  	endScreen()
  }	
}
function startScreen(){
		background(255, 157, 96)
		fill(255)
		textAlign(CENTER);
        textSize(20);
		text('Hello there, Find and Click the Smallest Circle to get points.', width / 2, height / 2)
        text('Reach 20 to Win!',width / 2, height / 2 + 20)
		text('Click Here to Start', width / 2, height / 2 + 40);
		resetScore();
        resetTime()
}

function gameOn() {
 	background(220);
  // Draw a circle
  noStroke();
  fill(r, g, b);
  ellipse(x, y, radius*2, radius*2);
  fill(r1, g1, b1);
  ellipse(x1, y1, radius*3, radius*3);
  textSize(24);
  text("Score: " + score, 300, 30);
  
  if (frameCount % 60 == 0 && timer <= 1000) { // if the frameCount is divisible by 60, then a second has passed. it will stop at 0
    timer ++;
  }
}

// When the user clicks the mouse
function mousePressed() {
  // Check if mouse is inside the circle
  let d = dist(mouseX, mouseY, x, y);
  
  if (d < radius) {
    newCircle();
    score++;
  }
  if(screen==0){
  	screen=1
  }else if(screen==1 && score == 20){
  	screen=2
    winSound.play();
  }else if(screen==2){
    screen=0
  }
}
function resetScore(){
  score =0;
}
function endScreen(){
		background(0)
        textAlign(CENTER);
        textSize(24);
		text('GAME OVER', width / 2, height / 2)
  	text("Time = " + timer + " seconds", width / 2, height / 2 + 20)
		text('Click Here to play again', width / 2, height / 2 + 40);
  
}
function resetTime(){
  timer = 0;
}

function newCircle() {
  x = random(width);
  y = random(height);
  x1 = random(width);
  y1 = random(height)
  radius=random(30,80)
  r = random(155);
  g = random(255);
  b = random(255);
  r1 = random(155);
  g1 = random(215);
  b1 = random(255);
}

setInterval(newCircle, 6000);
function gotolink_act1() {
	window.open('https://editor.p5js.org/Rudra_shah/full/Vf9NJ0gTM');
}