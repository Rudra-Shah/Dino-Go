var screen = 0;
var y=-20;
var x=200;
var speed = 2;
var score= 0;
let sound;
let bg;

function setup() {
  createCanvas(600,600);
  bg = loadImage('Background for Catching Game.jpg')
   var drawbutton = createButton('Home Screen');
 drawbutton.position(0, 0);
  drawbutton.mousePressed(gotolink_act1);
  sound = loadSound('mixkit-attention-bell-ding-586.wav');
}

function draw() {
	if(screen == 0){
    startScreen()
  }else if(screen == 1){
  	gameOn()
  }else if(screen==2){
  	endScreen()
  }	
}

function startScreen(){
		background(32, 179, 35)
		fill(255)
		textAlign(CENTER);
        textSize(20);
		text('Hello there, Catch the falling balls', width / 2, height / 2)
		text('into the box at the bottom. Click Here to Begin', width / 2, height / 2 + 20);
		reset();
}

function gameOn(){
	background(bg)
  text("score = " + score, 350,20)
  fill(255, 119, 15)
  ellipse(x,y,20,20)
  fill(50)
  rectMode(CENTER)
   rect(mouseX,height-10,50,30)
	y+= speed;
  if(y>height){
  	screen =2
	 }
  if(y>height-10 && x>mouseX-20 && x<mouseX+20){
  	y=-20
    speed+=.4
    score+= 1
  }
	if(y==-20){
  	pickRandom();
  }
}

function pickRandom(){
	x= random(20,width-20);
  sound.play();
}

function endScreen(){
		background(10, 113, 247)
		textAlign(CENTER);
		text('GAME OVER', width / 2, height / 2)
  	text("SCORE = " + score, width / 2, height / 2 + 20)
		text('click to play again', width / 2, height / 2 + 40);
}

function mousePressed(){
	if(screen==0){
  	screen=1
  }else if(screen==2){
  	screen=0
  }
}

function reset(){
	  score=0;
  	speed=2;
  	y=-20;
}
function gotolink_act1() {
	window.open('https://editor.p5js.org/Rudra_shah/full/Vf9NJ0gTM');
}