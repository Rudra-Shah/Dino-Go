let bg;
let y = 0;
function setup() {
  createCanvas(600, 600);
  bg = loadImage('Dinosaur Game GUI-5.jpg');
  createCanvas(600, 600);
  
  var drawbutton = createButton('Activity 1');
 drawbutton.position(200, 210);
  drawbutton.mousePressed(gotolink_act1);
 
  var drawbutton1 = createButton('Activity 2');
  drawbutton1.position(330, 210);
  drawbutton1.mousePressed(gotolink_act2);
 
  var drawbutton2 = createButton('Activity 3');
  drawbutton2.position(200, 250);
  drawbutton2.mousePressed(gotolink_act3);
  
  var drawbutton3 = createButton('Activity 4');         drawbutton3.position(330, 250);                                                                    
  drawbutton3.mousePressed(gotolink_act4);
  
}
function drawCircle(){
  ellipse(200,200,200,200)
}
function draw() {
   background(bg);
 
  y++;
  if (y > height) {
    y = 0;
}
  
}
// ball catcher
function gotolink_act1() {
	window.open('https://editor.p5js.org/djmiramo/full/digsxqMW9');
}
// small ball
function gotolink_act2() {
	window.open('https://editor.p5js.org/Rudra_shah/full/dDXPbvgiE');
}
// reaction 
function gotolink_act3() {
	window.open('https://editor.p5js.org/Rudra_shah/full/zsvPTtsVH');
}
// match the shapes 
function gotolink_act4() {
window.open('https://editor.p5js.org/djmiramo/full/2eU3bno1L');
}
