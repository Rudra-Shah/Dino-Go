//movable objects variables
var screen = 0;
let bg;

let circ1x = 100;
let circ1y = 100;
let diameterCircle1 = 50;
let draggingCircle = false;

let circ2x = 425;
let circ2y = 450;
let diameterCircle2 = 50;

let sq1x = 75;
let sq1y = 200;
let lengthSquare1 = 50;
let draggingSquare = false;

let sq2x=400;
let sq2y=75; 
let lengthSquare2 = 50;

let rec1x = 75;
let rec1y = 310;
let lengthRec1 = 100;
let widthRec1 = 50;
let draggingRec = false;

let rec2x = 325;
let rec2y = 250;
let lengthRec2 = 100;
let widthRec2 = 50;

let sound;

function setup() {
  createCanvas(600, 600);
  bg = loadImage('Background for Matching Game (2).jpg');
   var drawbutton = createButton('Home Screen');
 drawbutton.position(0, 0, 'relative');
  drawbutton.mousePressed(gotolink_act1);
  sound = loadSound('success_bell-6776.mp3');

}

function draw() {
	if(screen == 0){
    startScreen()
  }else if(screen == 1){
  	gameOn()
  }else if(screen==2){
  	endScreen()
  }	
}
function startScreen() {
  background(255, 157, 96)
		fill(255)
		textAlign(CENTER);
		text('Hello There, Match the Brown Coloured Shapes with the Shapes next to the Dinosaurs', width / 2, height / 3)
		text('Click Here to Start', width / 2, height / 3 + 20);
}
function gameOn() {
  background(bg);
  //stationary shapes
  fill(255)
  rect(sq2x,sq2y,lengthSquare2,lengthSquare2);
  fill(255);
  ellipse(circ2x,circ2y,diameterCircle2,diameterCircle2);
  fill(255)
  rect(rec2x, rec2y, lengthRec2, widthRec2)
  
  //if dragging is true
  //set x, y to mouseX, mouseY
  if(draggingCircle){
    circ1x = mouseX;
    circ1y = mouseY;
  }
  if(draggingSquare){
    sq1x = mouseX-25;
    sq1y = mouseY-25;
  }
  if(draggingRec){
    rec1x = mouseX - 50;
    rec1y = mouseY - 25;
  }
  
  noStroke();
  fill(255)
  ellipse(circ1x, circ1y, diameterCircle1, diameterCircle1);
  rect(sq1x, sq1y, lengthSquare1, lengthSquare1);
  rect(rec1x, rec1y, lengthRec1, widthRec1);
  
  var collision1 = checkCollision1(sq1x, sq1y, lengthSquare1, lengthSquare1, sq2x, sq2y, lengthSquare2, lengthSquare2);
  if (collision1) {
    fill(0);
  } else {
    fill(191, 132, 73);
  }
  rect(sq1x, sq1y, lengthSquare1, lengthSquare1);
  
  var collision2 = checkCollision2(circ1x, circ1y, diameterCircle1, diameterCircle1, circ2x, circ2y, diameterCircle2, diameterCircle2);
  if (collision2) {
    fill(0);
  } else {
    fill(191, 132, 73);
  }
  ellipse(circ1x, circ1y, diameterCircle1, diameterCircle1);
  
  var collision3 = checkCollision3(rec1x, rec1y, lengthRec1, widthRec1, rec2x, rec2y, lengthRec2, widthRec2);
  if (collision3) {
    fill(0);
  } else {
    fill(191, 132, 73);
  }
  rect(rec1x, rec1y, lengthRec1, widthRec1);
  
  if (collision1 && collision2 && collision3){
    text('Click Anywhere to End Game', width / 4, height / 3 + 20);
  }
}//end draw

function checkCollision1(s1x, s1y,  s1w, s1h,  s2x, s2y, s2w,s2h) {
  // store the locations of each rectangles outer borders 
  var top1 = s1y-s1h/2;
  var bottom1 = s1y+s1h/2;
  var right1 = s1x+s1w/2;
  var left1 = s1x-s1w/2;
  var top2 = s2y-s2h/2;
  var bottom2 = s2y+s2h/2;
  var right2 = s2x+s2w/2;
  var left2 = s2x-s2w/2;

  if (top1>bottom2 || bottom1<top2 || right1<left2 || left1>right2) {
    return false;
  } else {
    return true;
  }
}
function checkCollision2(c1x, c1y,  c1w, c1h,  c2x, c2y, c2w,c2h) {
  // store the locations of each rectangles outer borders 
  var top1 = c1y-c1h/2;
  var bottom1 = c1y+c1h/2;
  var right1 = c1x+c1w/2;
  var left1 = c1x-c1w/2;
  var top2 = c2y-c2h/2;
  var bottom2 = c2y+c2h/2;
  var right2 = c2x+c2w/2;
  var left2 = c2x-c2w/2;

  if (top1>bottom2 || bottom1<top2 || right1<left2 || left1>right2) {
    return false;
  } else {
    return true;
  }
}
function checkCollision3(r1x, r1y,  r1w, r1h,  r2x, r2y, r2w,r2h) {
  // store the locations of each rectangles outer borders 
  var top1 = r1y-r1h/2;
  var bottom1 = r1y+r1h/2;
  var right1 = r1x+r1w/2;
  var left1 = r1x-r1w/2;
  var top2 = r2y-r2h/2;
  var bottom2 = r2y+r2h/2;
  var right2 = r2x+r2w/2;
  var left2 = r2x-r2w/2;

  if (top1>bottom2 || bottom1<top2 || right1<left2 || left1>right2) {
    return false;
  } else {
    return true;
  }
}
function endScreen(){
		background(150);
		textAlign(CENTER);
		text('GAME OVER', width / 2, height / 3);
  text('Click Here To Restart', width / 2, height / 3 + 20);
}

/*when mouse is pressed, 
check if mouse is intersecting w/ circle or square */
function mousePressed() {
  //check if mouse is over the ellipse
  if(dist(circ1x, circ1y, mouseX, mouseY) < diameterCircle1/2){
    draggingCircle = true;
  }
  if(dist(sq1x,sq1y,mouseX,mouseY) < lengthSquare1){
    draggingSquare = true;
  }
  if(dist(rec1x, rec1y, mouseX, mouseY) < lengthRec1/ 1.5){
    draggingRec = true;
  }
  
  var collision1 = checkCollision1(sq1x, sq1y, lengthSquare1, lengthSquare1, sq2x, sq2y, lengthSquare2, lengthSquare2);
  var collision2 = checkCollision2(circ1x, circ1y, diameterCircle1, diameterCircle1, circ2x, circ2y, diameterCircle2, diameterCircle2);
  var collision3 = checkCollision3(rec1x, rec1y, lengthRec1, widthRec1, rec2x, rec2y, lengthRec2, widthRec2);
  
  
  if(screen==0){
  	screen=1;
  } else if(screen == 1 && collision1 && collision2 && collision3){
    screen=2;
    sound.play();
  } else if(screen == 2){
    resetgame();
    screen=0;
  }
}
function resetgame(){
circ1x = 100;
circ1y = 100;
diameterCircle1 = 50;
draggingCircle = false;

circ2x = 425;
circ2y = 500;
diameterCircle2 = 50;

sq1x = 75;
sq1y = 200;
lengthSquare1 = 50;
draggingSquare = false;
sq2x=400;
sq2y=75; 
lengthSquare2 = 50;

rec1x = 75;
rec1y = 310;
lengthRec1 = 100;
widthRec1 = 50;
draggingRec = false;

rec2x = 325;
rec2y = 250;
lengthRec2 = 100;
widthRec2 = 50;

}


function mouseReleased(){
  draggingCircle = false;
  draggingSquare = false;
  draggingRec = false;
}

function gotolink_act1() {
	window.open('https://editor.p5js.org/Rudra_shah/full/Vf9NJ0gTM');
}
